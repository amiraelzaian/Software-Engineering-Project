﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Training_System.BLL.Settings
{
    public class PaginationSetting
    {
        public int PageSize { get; set; } 
    }
}
