﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Training_System.BLL.Helpers;
using Training_System.BLL.ViewModel;
using Training_System.DAL.Models;
using Training_System.DAL.Models.Enums;

namespace Training_System.BLL.Services.Interfaces
{
    public interface IUserService
    {
        Task<IEnumerable<User>> GetInstructors();
        Task<Pagination<User>> GetAllAsync(string? search, UserRole? role, int pageIndex, int? pageSize);
        Task<User?> GetByIdAsync(int id);
        Task<UserViewModel?> GetByIdAsyncVM(int id);
        Task<User> AddAsync(User user);
        Task<User?> UpdateAsync(User user);
        Task<bool> DeleteAsync(int id);
        Task<bool> IsEmailUniqueAsync(string email, int? userId = null);
    }
}
