﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Training_System.BLL.Helpers;
using Training_System.BLL.ViewModel;
using Training_System.DAL.Models;

namespace Training_System.BLL.Services.Interfaces
{
    public interface IGradeService
    {
        Task<List<GradeViewModel>> GetGradesPerTrainee(int id);
        Task<Pagination<UserViewModel>> UsersWithGrades(int pageIndex, int? pageSize);
        Task AddGradeAsync(int traineeId, int sessionId, decimal value);
    }
}
