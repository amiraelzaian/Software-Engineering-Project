﻿using Training_System.BLL.Helpers;
using Training_System.BLL.ViewModel;
using Training_System.DAL.Models;
using Microsoft.EntityFrameworkCore;

namespace Training_System.BLL.Interfaces
{
    public interface ICourseService
    {
        Task<IEnumerable<Course>> GetAllAsync();
        Task<Pagination<CourseViewModel>> GetPagedAsync(string? search, string? category, int pageIndex, int? pageSize);
        Task<ICollection<string>> getcategories();
        Task<bool> IsNameExistAsync(string name, int? excludeId);

        Task<int> CountAsync(string? search);
        Task<Course?> GetByIdAsync(int id);
        Task<CourseViewModel> GetByIdAsyncVM(int id);
        Task AddAsync(Course course);
        void Update(Course course);
        void Delete(int id);
        Task<List<Course>> GetCoursesName();
        Task SaveAsync();
    }
}
