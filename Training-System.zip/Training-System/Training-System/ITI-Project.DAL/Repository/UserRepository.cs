﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Training_System.DAL.Models;
using Training_System.DAL.Models.Enums;
using Training_System.DAL.Repository.Interfaces;
using Microsoft.EntityFrameworkCore;

namespace Training_System.DAL.Repository
{
    public class UserRepository : GenericRepository<User>, IUserRepository
    {
        private readonly AppDbContext _context;
        public UserRepository(AppDbContext context) : base(context)
        {
            _context = context;
        }
        public async Task<List<User>> GetInstructors()
        {
            return await _context.Users.Where(e=>e.Role== UserRole.Instructor).ToListAsync();
             
        }
    }
}
