﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Training_System.DAL.Models;

namespace Training_System.DAL.Repository.Interfaces
{
    public interface ICourseRepository: GenaricRepository<Course>
    {
    }
}
